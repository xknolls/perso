<?php
namespace Model\Chess;

final class Peon extends \Model\Pawn 
{
    /**@var string */
    protected const SYMBOL = 'p';
}