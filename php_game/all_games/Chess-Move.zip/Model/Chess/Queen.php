<?php
namespace Model\Chess;

final class Queen extends \Model\Pawn 
{
    /**@var string */
    protected const SYMBOL = 'Q';
}