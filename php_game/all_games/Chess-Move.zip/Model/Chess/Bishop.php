<?php
namespace Model\Chess;

final class Bishop extends \Model\Pawn 
{
    /**@var string */
    protected const SYMBOL = 'b';
}