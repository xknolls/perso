<?php
namespace Model\Chess;

final class King extends \Model\Pawn 
{
    /**@var string */
    protected const SYMBOL = 'K';
}