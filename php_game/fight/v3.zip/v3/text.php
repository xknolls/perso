<?php

/**
 * Définition du type de perso avec des constante ligne 8/9 avec des constante
 * Ajout dans les objets des persos de la ligne 'type'
 * Dans function.php la fonction display_player 
 *      Ajout de l'affichage du type du perso
 * 
 */