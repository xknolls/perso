<?php 
/**
 * Stocker des chemins dans des constantes 
 * 
 */

/* ----------------------------------- Log ---------------------------------- */
define('PATH_LOG', 'logs/');

/* --------------------------------- Thèmes --------------------------------- */
define('THEMES_PATH', 'themes/');
define('THEME_DEFAULT', 'dark');

/* --------------------------------- Médias --------------------------------- */
define('PATH_MEDIAS', 'medias/');
define('MEDIAS_DEFAULT', 'macro');