Étape 1 : pour jeudi 18 mars 

- rédiger les spécifications fonctionnelles
- élaborer une maquette
- mettre en place un projet respectant une architecture MVC
- mettre en place les utilitaires permettant la gestion d'une galerie dynamique

# ------------------- rédiger les spécifications fonctionnelles -------------------- #

Objectifs pédagogiques 

- Renforcer sa capacité à créer une fonctionnalité
- Renforcer sa capacité à la décrire
- Se préparer à la réalisation du Dossier Professionnel (obligatoire pour le Titre)
- Renforcer ses compétences techniques: 
-- réalisation d'une interface utilisateur dans le respect des normes techniques et ergonomiques
-- manipulation du DOM afin de dynamiser une interface utilisateur

Objectif du projet

Présentation d'une galerie de photos.

## Fonctionnalités attendues 

La galerie se présente sous forme de miniatures
L'utilisateur peut accéder à la version agrandie de la photo en cliquant sur sa miniature
La fonctionnalité doit être paramétrable afin de pouvoir être personnalisée pour différents projets (choix d'un album, présentation de plusieurs albums sur la même page, choix d'une ambiance graphique)

# ------------------------------ élaborer une maquette ----------------------------- #

# ------------ mettre en place un projet respectant une architecture MVC ----------- #

#-- mettre en place les utilitaires permettant la gestion d'une galerie dynamique -- #

equipe examen shunin

dynamique
nouveau controleur 'all?'
page qui affiche toutes les galeries dans une section
avec un zoom qui marche pour chaque galerie